Zlib 1.2.3 + MiniZip Dynamic Library
based on code by Gilles Vollant

Building instructions for the Mac OS X version 
==============================================

This directory contains a project that builds zlib and minizip 
using XCode 2.2.1+.

You don't need to build these projects yourself. 
You can download the binaries from:
  http://olegykj.sourceforge.net/

More information can be found at this site.


Build instructions for XCode 2.2.1+
--------------------------------------------------
- Uncompress current zlib, including all contrib/* files
- Open contrib\macosx\zlib.xcodeproj with XCode.


Additional notes
----------------
- This library, named libzlib.dylib, is renamed because the 
version of libz.dylib included in Mac OS X does not contain 
the minizip module.


Oleg Kobchenko
olegyk@yahoo.com
